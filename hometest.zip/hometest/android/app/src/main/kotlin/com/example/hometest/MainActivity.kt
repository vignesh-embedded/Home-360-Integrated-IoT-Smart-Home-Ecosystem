package com.example.hometest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
