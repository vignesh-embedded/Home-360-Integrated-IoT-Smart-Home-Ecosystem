import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'cameraScreen.dart'; // Import the CameraScreen

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: "AIzaSyAb_61s6k2Eq0Wd_S9A8oNcHYj1DwprHjE",
      authDomain: "home-360-94ca3.firebaseapp.com",
      databaseURL: "https://home-360-94ca3-default-rtdb.firebaseio.com",
      projectId: "home-360-94ca3",
      storageBucket: "home-360-94ca3.firebasestorage.app",
      messagingSenderId: "107181179937",
      appId: "1:107181179937:web:b53f4ae96eefab6e964f60",
      measurementId: "G-3WE87PMR21",
    ),
  );
  runApp(const Home360App());
}

class Home360App extends StatelessWidget {
  const Home360App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Home 360',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const LoginScreen(),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  void _login() async {
    const String predefinedUsername = 'team17';
    const String predefinedPassword = 'password';

    if (_emailController.text == predefinedUsername &&
        _passwordController.text == predefinedPassword) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
      return;
    }

    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: _emailController.text,
        password: _passwordController.text,
      );
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message ?? 'Invalid credentials')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.blue, Colors.purple],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/icon.png',
                  height: 150,
                  width: 150,
                ),
                const SizedBox(height: 20),
                const Text(
                  'Welcome to Home 360',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: 'Login id',
                    labelStyle: const TextStyle(color: Colors.white),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.3),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                    prefixIcon: const Icon(Icons.email, color: Colors.white),
                  ),
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    labelStyle: const TextStyle(color: Colors.white),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.3),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                    prefixIcon: const Icon(Icons.lock, color: Colors.white),
                  ),
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 30),
                ElevatedButton(
                  onPressed: _login,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 50, vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: const Text(
                    'Login',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home 360',
            style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          children: [
            FeatureCard(
              title: 'Home Control',
              icon: Icons.control_camera_sharp,
              color: const Color.fromARGB(255, 111, 5, 140),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const LightControlScreen()),
              ),
            ),
            FeatureCard(
              title: 'Theft Detection',
              icon: Icons.security,
              color: Colors.redAccent,
              onTap: () => navigateToFeature(
                context,
                'Theft Detection',
                Icons.security,
                'Detects unauthorized access and sends alerts.',
              ),
            ),
            FeatureCard(
              title: 'Live Cam',
              icon: Icons.videocam,
              color: Colors.blueAccent,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const CameraScreen(),
                  ),
                );
              },
            ),
            FeatureCard(
              title: 'Fitness',
              icon: Icons.fitness_center,
              color: Colors.greenAccent,
              onTap: () => navigateToFeature(
                context,
                'Fitness',
                Icons.fitness_center,
                'Monitors workouts and health metrics.',
              ),
            ),
            FeatureCard(
              title: 'Vehicle Management',
              icon: Icons.directions_car,
              color: Colors.orangeAccent,
              onTap: () => navigateToFeature(
                context,
                'Vehicle Management',
                Icons.directions_car,
                'Tracks and manages vehicle status.',
              ),
            ),
            FeatureCard(
              title: 'Energy Meter',
              icon: Icons.electric_meter,
              color: Colors.purpleAccent,
              onTap: () => navigateToFeature(
                context,
                'Energy Meter',
                Icons.electric_meter,
                'Monitors electricity usage efficiently.',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void navigateToFeature(
    BuildContext context, String title, IconData icon, String description) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => FeatureDetailScreen(
          title: title, icon: icon, description: description),
    ),
  );
}

class FeatureDetailScreen extends StatefulWidget {
  final String title;
  final IconData icon;
  final String description;

  const FeatureDetailScreen({
    super.key,
    required this.title,
    required this.icon,
    required this.description,
  });

  @override
  _FeatureDetailScreenState createState() => _FeatureDetailScreenState();
}

class _FeatureDetailScreenState extends State<FeatureDetailScreen> {
  String? _imageUrl;
  late DatabaseReference _imageUrlRef;

  @override
  void initState() {
    super.initState();
    if (widget.title == 'Energy Meter') {
      _imageUrlRef =
          FirebaseDatabase.instance.ref('energy_meter/last_image_url');
      _listenToImageUrl();
    }
  }

  void _listenToImageUrl() {
    _imageUrlRef.onValue.listen((event) {
      final data = event.snapshot.value;
      if (data != null) {
        setState(() {
          _imageUrl = data.toString();
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(widget.icon, size: 100, color: Colors.blue),
            const SizedBox(height: 20),
            Text(
              widget.title,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              widget.description,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            if (widget.title == 'Energy Meter') ...[
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    _sendCaptureCommand();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Capture command sent!'),
                        duration: Duration(seconds: 2),
                      ),
                    );
                  },
                  child: const Text('Capture Image'),
                ),
              ),
              const SizedBox(height: 20),
              if (_imageUrl != null)
                CachedNetworkImage(
                  imageUrl: _imageUrl!,
                  placeholder: (context, url) =>
                      const CircularProgressIndicator(),
                  errorWidget: (context, url, error) => const Icon(Icons.error),
                  width: 300,
                  height: 200,
                  fit: BoxFit.cover,
                )
              else
                const Text('No image captured yet'),
            ],
          ],
        ),
      ),
    );
  }

  void _sendCaptureCommand() {
    final DatabaseReference captureRef =
        FirebaseDatabase.instance.ref('capture_command');
    captureRef.set(true).then((_) {
      print('Capture command sent to Firebase');
      Future.delayed(const Duration(seconds: 5), () {
        captureRef.set(false).then((_) {
          print('Capture command reset to false');
        }).catchError((error) {
          print('Failed to reset capture command: $error');
        });
      });
    }).catchError((error) {
      print('Failed to send capture command: $error');
    });
  }

  @override
  void dispose() {
    if (widget.title == 'Energy Meter') {
      _imageUrlRef.onDisconnect();
    }
    super.dispose();
  }
}

class FeatureCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const FeatureCard({
    super.key,
    required this.title,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 5,
              spreadRadius: 2,
              offset: const Offset(2, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.white),
            const SizedBox(height: 10),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}

class LightControlScreen extends StatefulWidget {
  const LightControlScreen({super.key});

  @override
  _LightControlScreenState createState() => _LightControlScreenState();
}

class _LightControlScreenState extends State<LightControlScreen> {
  bool _isLightOn = false;
  final DatabaseReference _lightRef =
      FirebaseDatabase.instance.ref('lights/light1');

  @override
  void initState() {
    super.initState();
    _listenToLightStatus();
  }

  void _listenToLightStatus() {
    _lightRef.onValue.listen((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data != null) {
        setState(() {
          _isLightOn = data['isOn'] ?? false;
        });
      }
    });
  }

  void _toggleLight() async {
    setState(() {
      _isLightOn = !_isLightOn;
    });

    await _lightRef.set({
      'isOn': _isLightOn,
      'lastUpdated': ServerValue.timestamp,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Light Control'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              _isLightOn ? Icons.lightbulb : Icons.lightbulb_outline,
              size: 100,
              color: _isLightOn ? Colors.yellow : Colors.grey,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _toggleLight,
              child: Text(_isLightOn ? 'Turn Off' : 'Turn On'),
            ),
          ],
        ),
      ),
    );
  }
}
