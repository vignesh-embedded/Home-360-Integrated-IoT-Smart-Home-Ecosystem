import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class CameraScreen extends StatelessWidget {
  const CameraScreen({super.key});

  // Function to open the URL in a WebView
  void openURL(BuildContext context, String url) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => WebViewScreen(url: url),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Live Cam")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FeatureCard(
              title: "Local Server",
              description:
                  "Tap the button to open the local server in a WebView.",
              icon: Icons.storage,
              onPressed: () => openURL(context, "http://192.168.21.47:8080"),
            ),
            const SizedBox(height: 20),
            FeatureCard(
              title: "Remote Server",
              description:
                  "Tap the button to open the remote server in a WebView.",
              icon: Icons.public,
              onPressed: () => openURL(context,
                  "https://e1a7-2409-40f4-411d-e0e2-218f-b71c-6d7a-71e3.ngrok-free.app/"),
            ),
          ],
        ),
      ),
    );
  }
}

/// A custom feature card widget
class FeatureCard extends StatelessWidget {
  final String title;
  final String description;
  final IconData icon;
  final VoidCallback onPressed;

  const FeatureCard({
    super.key,
    required this.title,
    required this.description,
    required this.icon,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 48, color: Theme.of(context).primaryColor),
            const SizedBox(height: 16),
            Text(
              title,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              description,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: onPressed,
              style: ElevatedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text("Open URL"),
            ),
          ],
        ),
      ),
    );
  }
}

/// WebView Screen using flutter_inappwebview
class WebViewScreen extends StatelessWidget {
  final String url;

  const WebViewScreen({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("WebView"),
      ),
      body: InAppWebView(
        initialUrlRequest: URLRequest(url: WebUri(url)), // Use WebUri here
        initialOptions: InAppWebViewGroupOptions(
          crossPlatform: InAppWebViewOptions(
            javaScriptEnabled: true, // Enable JavaScript
          ),
        ),
      ),
    );
  }
}
