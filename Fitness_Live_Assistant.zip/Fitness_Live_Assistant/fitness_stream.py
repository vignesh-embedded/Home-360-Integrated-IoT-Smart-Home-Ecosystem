import cv2
import numpy as np
import mediapipe as mp
from flask import Flask, Response, render_template_string

app = Flask(__name__)

# Function to calculate angle
def calculate_angle(a, b, c):
    a = np.array(a)  # First
    b = np.array(b)  # Mid
    c = np.array(c)  # End
    radians = np.arctan2(c[1] - b[1], c[0] - b[0]) - np.arctan2(a[1] - b[1], a[0] - b[0])
    angle = np.abs(radians * 180.0 / np.pi)
    if angle > 180.0:
        angle = 360 - angle
    return angle

# Initialize mediapipe
mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils

# Global variables for curl counters and stream control
counter_left = 0
counter_right = 0
stage_left = None
stage_right = None
stream_active = False
reset_stream = False
reset_counters = False

def generate_frames():
    global counter_left, counter_right, stage_left, stage_right, stream_active, reset_stream, reset_counters

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return

    with mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        while cap.isOpened():
            if not stream_active:
                continue

            ret, frame = cap.read()
            if not ret:
                print("Error: Failed to capture frame.")
                break

            # Recolor image to RGB
            image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image.flags.writeable = False

            # Make detection
            results = pose.process(image)

            # Recolor back to BGR
            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

            # Extract landmarks
            try:
                landmarks = results.pose_landmarks.landmark

                # Left arm coordinates
                shoulder_left = [landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x, landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
                elbow_left = [landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].x, landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
                wrist_left = [landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].x, landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].y]

                # Right arm coordinates
                shoulder_right = [landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].x, landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].y]
                elbow_right = [landmarks[mp_pose.PoseLandmark.RIGHT_ELBOW.value].x, landmarks[mp_pose.PoseLandmark.RIGHT_ELBOW.value].y]
                wrist_right = [landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value].x, landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value].y]

                # Calculate angles
                angle_left = calculate_angle(shoulder_left, elbow_left, wrist_left)
                angle_right = calculate_angle(shoulder_right, elbow_right, wrist_right)

                # Visualize left arm angle
                cv2.putText(image, str(angle_left),
                            tuple(np.multiply(elbow_left, [640, 480]).astype(int)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)

                # Visualize right arm angle
                cv2.putText(image, str(angle_right),
                            tuple(np.multiply(elbow_right, [640, 480]).astype(int)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)

                # Curl counter logic for left arm
                if angle_left > 160:
                    stage_left = "down"
                if angle_left < 30 and stage_left == 'down':
                    stage_left = "up"
                    counter_left += 1
                    print(f"Left Curls: {counter_left}")

                # Curl counter logic for right arm
                if angle_right > 160:
                    stage_right = "down"
                if angle_right < 30 and stage_right == 'down':
                    stage_right = "up"
                    counter_right += 1
                    print(f"Right Curls: {counter_right}")

            except Exception as e:
                print(f"Error in generate_frames: {e}")
                continue

            # Render curl counter for both arms
            # Setup status box for left arm
            cv2.rectangle(image, (0, 0), (225, 73), (245, 117, 16), -1)
            cv2.putText(image, 'LEFT REPS', (15, 12),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(image, str(counter_left),
                        (10, 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 2, cv2.LINE_AA)

            # Setup status box for right arm
            cv2.rectangle(image, (0, 80), (225, 153), (245, 117, 16), -1)
            cv2.putText(image, 'RIGHT REPS', (15, 92),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(image, str(counter_right),
                        (10, 140),
                        cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 2, cv2.LINE_AA)

            # Stage data for both arms
            cv2.putText(image, '     & STAGE', (65, 12),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(image, stage_left,
                        (60, 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 2, cv2.LINE_AA)

            cv2.putText(image, '      & STAGE', (65, 92),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(image, stage_right,
                        (60, 140),
                        cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 2, cv2.LINE_AA)

            # Render detections
            mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                     mp_drawing.DrawingSpec(color=(245, 117, 66), thickness=2, circle_radius=2),
                                     mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=2))

            # Display MediaPipe output in a separate window
            cv2.imshow('MediaPipe Output', image)

            # Clone the image for streaming
            stream_image = image.copy()

            # Reset counters if requested
            if reset_counters:
                counter_left = 0
                counter_right = 0
                reset_counters = False

            # Reset stream if requested
            if reset_stream:
                stream_image = np.zeros_like(image)
                reset_stream = False

            # Encode the frame as JPEG
            ret, buffer = cv2.imencode('.jpg', stream_image)
            if not ret:
                print("Error: Failed to encode frame.")
                break
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()
    cv2.destroyAllWindows()

@app.route('/')
def index():
    return render_template_string('''
        <!DOCTYPE html>
        <html>
        <head>
            <title>MediaPipe Stream</title>
        </head>
        <body>
            <h1>MediaPipe Stream</h1>
            <img src="{{ url_for('video_feed') }}" width="640" height="480">
            <br>
            <button onclick="startStream()">Start Stream</button>
            <button onclick="stopStream()">Stop Stream</button>
            <button onclick="resetStream()">Reset Stream</button>
            <button onclick="resetCounters()">Reset Counters</button>
            <script>
                function startStream() {
                    fetch('/start_stream');
                }
                function stopStream() {
                    fetch('/stop_stream');
                }
                function resetStream() {
                    fetch('/reset_stream');
                }
                function resetCounters() {
                    fetch('/reset_counters');
                }
            </script>
        </body>
        </html>
    ''')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/start_stream')
def start_stream():
    global stream_active
    stream_active = True
    return "Stream started"

@app.route('/stop_stream')
def stop_stream():
    global stream_active
    stream_active = False
    return "Stream stopped"

@app.route('/reset_stream')
def reset_stream():
    global reset_stream
    reset_stream = True
    return "Stream reset"

@app.route('/reset_counters')
def reset_counters():
    global reset_counters
    reset_counters = True
    return "Counters reset"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)