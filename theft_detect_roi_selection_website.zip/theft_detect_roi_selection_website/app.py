from flask import Flask, render_template, Response, request, jsonify, redirect, url_for
import cv2
import imutils

app = Flask(__name__)

# Initialize tracker
tracker = cv2.TrackerKCF_create()
video = cv2.VideoCapture(0)  # Use 0 for default webcam or IP camera URL

if not video.isOpened():
    print("Error: Could not open webcam.")
    exit()

frame_width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))

# Global variables for tracking
BB = None
tracking = False

def generate_frames():
    global BB, tracking
    while True:
        ret, frame = video.read()
        if not ret:
            print("Error: Failed to read frame from video source.")
            break

        frame = imutils.resize(frame, width=min(720, frame_width))

        if tracking:
            track_success, BB = tracker.update(frame)
            if track_success:
                top_left = (int(BB[0]), int(BB[1]))
                bottom_right = (int(BB[0] + BB[2]), int(BB[1] + BB[3]))
                cv2.rectangle(frame, top_left, bottom_right, (0, 255, 0), 5)
                cv2.putText(frame, "Tracking Object", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            else:
                cv2.putText(frame, "Tracking Lost", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

        ret, buffer = cv2.imencode('.jpg', frame)
        if not ret:
            print("Error: Failed to encode frame.")
            continue

        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/select_roi')
def select_roi():
    return render_template('select_roi.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame',
                    headers={'Cache-Control': 'no-cache, no-store, must-revalidate',
                             'Pragma': 'no-cache',
                             'Expires': '0'})

@app.route('/set_roi', methods=['POST'])
def set_roi():
    global BB, tracking, tracker
    data = request.json
    if not data or 'x' not in data or 'y' not in data or 'w' not in data or 'h' not in data:
        return jsonify({"error": "Invalid ROI data"}), 400

    BB = (data['x'], data['y'], data['w'], data['h'])

    # Restart the tracker with new ROI
    ret, frame = video.read()
    if not ret:
        return jsonify({"error": "Cannot read video frame"}), 500

    frame = imutils.resize(frame, width=min(720, frame_width))
    tracker = cv2.TrackerKCF_create()
    tracker.init(frame, BB)
    tracking = True

    return jsonify({"success": True})

@app.route('/reset_roi')
def reset_roi():
    global BB, tracking, tracker
    BB = None
    tracking = False
    tracker = cv2.TrackerKCF_create()  # Reinitialize the tracker
    return redirect(url_for('index'))  # Redirect to the main page

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)