import cv2
import numpy as np
import imutils
import easyocr
import requests
import time
import firebase_admin
import re
from firebase_admin import credentials, db
from PIL import Image
import base64

# Initialize Firebase
cred = credentials.Certificate(r"D:\Finalyear_Project\Home360_BackEnd\Vechicle_num_detect\home360-973ac-firebase-adminsdk-fbsvc-c1704fb8c6.json")
firebase_admin.initialize_app(cred, {
    'databaseURL':'https://home-360-94ca3-default-rtdb.firebaseio.com/'
})

# Initialize EasyOCR reader with more languages and better configuration
reader = easyocr.Reader(['en'], gpu=True)  # Enable GPU if available

# Initialize camera with better resolution
cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

# ImgBB API key
IMGBB_API_KEY = '677093d2ace7ca3651c15bfcfaa421ec'

# Indian number plate regex pattern
INDIAN_PLATE_PATTERN = re.compile(
    r'^[A-Z]{2}[0-9]{1,2}[A-Z]{1,2}[0-9]{3,4}$|'  # Standard format (e.g., MH01AB1234)
    r'^[A-Z]{2}[0-9]{2}[A-Z]{2}[0-9]{4}$'        # New format (e.g., TR03MF4477)
)

def preprocess_image(image):
    """Enhance image quality for better OCR results"""
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    gray = clahe.apply(gray)
    
    # Denoising
    gray = cv2.fastNlMeansDenoising(gray, h=10)
    
    return gray

def compress_image(image_path, quality=85):
    """Compresses an image to reduce file size."""
    img = Image.open(image_path)
    img.save(image_path, quality=quality, optimize=True)

def upload_to_imgbb(image_path):
    """Uploads an image to ImgBB and returns the URL."""
    with open(image_path, "rb") as file:
        encoded_image = base64.b64encode(file.read()).decode('utf-8')
        
        url = "https://api.imgbb.com/1/upload"
        payload = {
            "key": IMGBB_API_KEY,
            "image": encoded_image,
        }
        response = requests.post(url, payload)
        print(f"ImgBB API Response: {response.status_code}, {response.text}")
        if response.status_code == 200:
            return response.json()['data']['url']
        else:
            print("Failed to upload image to ImgBB")
            return None

def save_to_firebase(text, image_url):
    """Saves the detected text and image URL to Firebase."""
    ref = db.reference('detected_plates')
    ref.push({
        'text': text,
        'image_url': image_url,
        'timestamp': time.time(),
        'valid_format': bool(INDIAN_PLATE_PATTERN.match(text))
    })

def validate_and_correct_plate(text):
    """Validate and attempt to correct Indian number plate format"""
    # Remove all whitespace and special characters
    clean_text = re.sub(r'[^a-zA-Z0-9]', '', text).upper()
    
    # Common OCR misreads replacements
    replacements = {
        '0': 'O',
        '1': 'I',
        '2': 'Z',
        '4': 'A',
        '5': 'S',
        '6': 'G',
        '8': 'B',
        'B': '8',
        'D': '0',
        'I': '1',
        'O': '0',
        'Q': '0',
        'S': '5',
        'Z': '2'
    }
    
    # Attempt to correct common OCR errors
    corrected = []
    for char in clean_text:
        if char in replacements and len(corrected) < 4:  # More likely to replace in letters part
            corrected.append(replacements[char])
        else:
            corrected.append(char)
    
    corrected_text = ''.join(corrected)
    
    # Check if the corrected text matches the pattern
    if INDIAN_PLATE_PATTERN.match(corrected_text):
        return corrected_text
    
    # If still not matching, return the original clean text
    return clean_text

def detect_plate_region(img):
    """Detect potential number plate regions in the image"""
    gray = preprocess_image(img)
    
    # Apply bilateral filter
    bfilter = cv2.bilateralFilter(gray, 11, 17, 17)
    
    # Edge detection
    edged = cv2.Canny(bfilter, 30, 200)
    
    # Find contours
    contours = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = imutils.grab_contours(contours)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]
    
    locations = []
    for contour in contours:
        epsilon = 0.02 * cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, epsilon, True)
        if len(approx) == 4:
            locations.append(approx)
    
    return locations

def process_frame(img):
    """Processes a frame to detect number plates."""
    # Detect all potential plate regions
    plate_regions = detect_plate_region(img)
    
    for location in plate_regions:
        mask = np.zeros(img.shape[:2], np.uint8)
        cv2.drawContours(mask, [location], 0, 255, -1)
        masked_img = cv2.bitwise_and(img, img, mask=mask)
        
        # Get bounding rect
        (x, y) = np.where(mask == 255)
        (x1, y1) = (np.min(x), np.min(y))
        (x2, y2) = (np.max(x), np.max(y))
        
        # Extract the region of interest
        cropped_image = img[x1:x2+1, y1:y2+1]
        
        # Preprocess the cropped image
        processed_crop = preprocess_image(cropped_image)
        
        # Perform OCR with more detailed configuration
        results = reader.readtext(
            processed_crop,
            detail=1,
            paragraph=False,
            batch_size=4,
            allowlist='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
            width_ths=0.5,
            height_ths=0.5
        )
        
        if results:
            # Combine all detected text
            combined_text = ' '.join([result[1] for result in results])
            
            # Validate and correct the plate format
            validated_text = validate_and_correct_plate(combined_text)
            
            # Only proceed if it matches Indian plate format
            if INDIAN_PLATE_PATTERN.match(validated_text):
                # Draw rectangle around the plate
                cv2.drawContours(img, [location], -1, (0, 255, 0), 3)
                
                # Save the detected image
                image_path = f"detected_plate_{time.time()}.jpg"
                cv2.imwrite(image_path, img)
                compress_image(image_path)
                
                # Upload image to ImgBB
                image_url = upload_to_imgbb(image_path)
                
                if image_url:
                    # Save data to Firebase
                    save_to_firebase(validated_text, image_url)
                    print(f"Detected: {validated_text}")
                    print(f"Image URL: {image_url}")
                
                return img, validated_text
    
    return img, None

# Main loop for continuous monitoring
try:
    while True:
        ret, img = cap.read()
        if not ret:
            break

        processed_img, text = process_frame(img)
        
        # Display the processed image
        cv2.imshow('Indian Number Plate Detection', processed_img)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
finally:
    cap.release()
    cv2.destroyAllWindows()